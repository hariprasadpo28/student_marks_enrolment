from django.apps import AppConfig


class StudentsMarksConfig(AppConfig):
    name = 'students_marks'
